const pages = document.querySelectorAll('.page');
const navBtns = document.querySelectorAll('.nav-btn');
const logDiv = document.getElementById('log');
const noticeModal = document.getElementById('noticeModal');
const noticeContent = document.getElementById('noticeContent');
const modalHint = document.querySelector('.modal-hint');

let isNoticeClosable = false;

navBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        navBtns.forEach(b => b.classList.remove('active'));
        pages.forEach(p => p.classList.remove('active'));

        btn.classList.add('active');
        const targetPage = document.getElementById(btn.dataset.page);
        if (targetPage) targetPage.classList.add('active');
    });
});

async function runScript(scriptName, successText) {
    if (!logDiv) return;
    logDiv.innerText = "⏳ 正在执行...";

    try {
        if (typeof ksu !== 'undefined' && ksu.exec) {
            await ksu.exec(`sh /data/adb/modules/hidedata/webroot/${scriptName}`);
            logDiv.innerText = `✅ ${successText}`;
            setTimeout(() => {
                logDiv.innerText = "等待执行...";
            }, 3000);
        } else {
            logDiv.innerText = "❌ 未检测到 KernelSU / APatch 环境";
            setTimeout(() => {
                logDiv.innerText = "等待执行...";
            }, 2500);
        }
    } catch (e) {
        logDiv.innerText = "❌ 执行失败";
        setTimeout(() => {
            logDiv.innerText = "等待执行...";
        }, 2500);
    }
}

const execBtnAll = document.getElementById('execBtnAll');
if (execBtnAll) {
    execBtnAll.addEventListener('click', () => runScript('script.sh', '一键配置执行成功'));
}

const execBtnAll2 = document.getElementById('execBtnAll2');
if (execBtnAll2) {
    execBtnAll2.addEventListener('click', () => runScript('script2.sh', '一键配置(scene版)执行成功'));
}

const execBtnAll3 = document.getElementById('execBtnAll3');
if (execBtnAll3) {
    execBtnAll3.addEventListener('click', () => runScript('script3.sh', 'ts密钥远程更新成功等待下载替换'));
}

function initNotice() {
    if (!noticeModal || !noticeContent) return;

    noticeModal.classList.add('show');
    noticeContent.innerHTML = "⏳ 正在获取公告内容...";
    
    isNoticeClosable = false;
    if (modalHint) {
        modalHint.innerText = "🔒 获取公告时无法关闭内容...";
        modalHint.style.color = "rgba(255, 255, 255, 0.5)";
    }
    
    setTimeout(async () => {
        if (typeof ksu !== 'undefined' && ksu.exec) {
            const cmds = [
                'API_RES=$(curl -4 -k -s --connect-timeout 2 "https://api.github.com/gists/c7bb8fd7b0d1215835b7337339f719cc"); URL=$(echo "$API_RES" | grep -o \'"raw_url": "[^"]*\' | head -n 1 | cut -d\'"\' -f4); [ -n "$URL" ] && curl -4 -k -sL "$URL" | base64 | tr -d "\\n\\r"',
                'curl -4 -k -sL --connect-timeout 2 --max-time 3 "https://ghproxy.net/https://gist.githubusercontent.com/josefapps/c7bb8fd7b0d1215835b7337339f719cc/raw/gonggao?t=$(date +%s)" | base64 | tr -d "\\n\\r"',
                'curl -4 -k -sL --connect-timeout 2 --max-time 3 "https://mirror.ghproxy.com/https://gist.githubusercontent.com/josefapps/c7bb8fd7b0d1215835b7337339f719cc/raw/gonggao?t=$(date +%s)" | base64 | tr -d "\\n\\r"'
            ];

            let finalNotice = "";
            let lastError = "所有网络备用通道请求均未返回有效文本";

            for (let i = 0; i < cmds.length; i++) {
                try {
                    const res = await ksu.exec(cmds[i]);
                    
                    let stdoutStr = "";
                    if (typeof res === 'string') {
                        stdoutStr = res.trim();
                    } else if (res && typeof res === 'object' && res.stdout) {
                        stdoutStr = res.stdout.trim();
                    }

                    if (stdoutStr && !stdoutStr.includes("404") && !stdoutStr.includes("Not Found")) {
                        try {
                            const binStr = atob(stdoutStr);
                            const bytes = new Uint8Array(binStr.length);
                            for(let j = 0; j < binStr.length; j++) {
                                bytes[j] = binStr.charCodeAt(j);
                            }
                            const decodedStr = new TextDecoder('utf-8').decode(bytes);
                            
                            const lines = decodedStr.split(/\r?\n|\r/);
                            finalNotice = lines.map(line => `<div>${line}</div>`).join('');
                            break; 
                        } catch(e) {
                            lastError = "通道数据解码失败: " + e.message;
                        }
                    }
                } catch (e) {
                    lastError = e.message;
                }
            }

            if (finalNotice) {
                noticeContent.innerHTML = finalNotice;
            } else {
                noticeContent.innerHTML = `❌ 远程公告加载失败。<br><br>原因提示：未能在所有备用通道中获取到有效文本。<br>错误详情：${lastError}<br><br>💡 提示：请确保您的 GitHub Gist 文本内容未被清空或删除。`;
            }
        } else {
            noticeContent.innerHTML = `💡 提示：当前未检测 to KernelSU 环境。<br>请在手机 KernelSU Manager 的 WebUI 中查看。`;
        }

        isNoticeClosable = true;
        if (modalHint) {
            modalHint.innerText = "点击周边关闭公告";
            modalHint.style.color = "rgba(255, 255, 255, 0.35)";
        }

    }, 100); 
}

if (noticeModal) {
    noticeModal.addEventListener('click', (e) => {
        if (e.target === noticeModal) {
            if (isNoticeClosable) {
                noticeModal.classList.remove('show');
            }
        }
    });
}

initNotice();


// ==========================================
// 👇 首页全量远程更新前端交互控制（原版）
// ==========================================
const updateModuleBtn = document.getElementById('updateModuleBtn');
const homeLog = document.getElementById('homeLog');

if (updateModuleBtn && homeLog) {
    updateModuleBtn.addEventListener('click', async () => {
        homeLog.style.display = 'block';
        homeLog.style.color = '#7dffa5';
        homeLog.innerText = "⏳ 正在连接服务器并下载新模块 ZIP...";
        updateModuleBtn.disabled = true;
        updateModuleBtn.style.opacity = '0.6';

        try {
            if (typeof ksu !== 'undefined' && ksu.exec) {
                const res = await ksu.exec('sh /data/adb/modules/hidedata/webroot/xz.sh');
                handleUpdateResult(res);
            } else {
                homeLog.innerText = "❌ 未检测到 KernelSU / APatch 环境，无法执行脚本。";
                homeLog.style.color = "#ff5252";
                resetUpdateBtn();
            }
        } catch (e) {
            homeLog.innerText = "❌ 执行异常: " + e.message;
            homeLog.style.color = "#ff5252";
            resetUpdateBtn();
        }
    });
}

function resetUpdateBtn() {
    if (updateModuleBtn) {
        updateModuleBtn.disabled = false;
        updateModuleBtn.style.opacity = '1';
    }
}


// ==========================================
// ✨ 新增：首页全量远程更新前端交互控制（过设备标记版）
// ==========================================
const updateModuleBtn2 = document.getElementById('updateModuleBtn2');

if (updateModuleBtn2 && homeLog) {
    updateModuleBtn2.addEventListener('click', async () => {
        // 1. 初始化UI状态，禁用当前按钮
        homeLog.style.display = 'block';
        homeLog.style.color = '#7dffa5';
        homeLog.innerText = "⏳ 正在连接服务器并下载新模块 ZIP(过设备标记版)...";
        updateModuleBtn2.disabled = true;
        updateModuleBtn2.style.opacity = '0.6';

        try {
            // 2. 核心修改：环境判断并执行全新的 xz2.sh 脚本[span_4](start_span)[span_4](end_span)
            if (typeof ksu !== 'undefined' && ksu.exec) {
                const res = await ksu.exec('sh /data/adb/modules/hidedata/webroot/xz2.sh');
                handleUpdateResult(res, resetUpdateBtn2);
            } else {
                homeLog.innerText = "❌ 未检测到 KernelSU / APatch 环境，无法执行脚本。";
                homeLog.style.color = "#ff5252";
                resetUpdateBtn2();
            }
        } catch (e) {
            homeLog.innerText = "❌ 执行异常: " + e.message;
            homeLog.style.color = "#ff5252";
            resetUpdateBtn2();
        }
    });
}

function resetUpdateBtn2() {
    if (updateModuleBtn2) {
        updateModuleBtn2.disabled = false;
        updateModuleBtn2.style.opacity = '1';
    }
}

// 提取共用的结果解析函数，精简代码且防止状态混乱
function handleUpdateResult(res, resetCallback = resetUpdateBtn) {
    let stdoutStr = "";
    if (typeof res === 'string') {
        stdoutStr = res.trim();
    } else if (res && res.stdout) {
        stdoutStr = res.stdout.trim();
    }

    if (stdoutStr === "SUCCESS") {
        homeLog.innerText = "✅ 模块更新成功！\n💡 关闭ksu重新打开加载。";
        homeLog.style.color = "#7dffa5";
    } else if (stdoutStr === "NETWORK_ERROR") {
        homeLog.innerText = "❌ 更新失败：网络无法连接，请检查手机联网状态或代理设置。";
        homeLog.style.color = "#ff5252";
        resetCallback();
    } else if (stdoutStr === "DOWNLOAD_FAILED") {
        homeLog.innerText = "❌ 更新失败：云端下载失败，请确认服务器文件是否存在。";
        homeLog.style.color = "#ff5252";
        resetCallback();
    } else if (stdoutStr === "UNZIP_FAILED") {
        homeLog.innerText = "❌ 更新失败：ZIP 压缩包可能已损坏，解压失败。";
        homeLog.style.color = "#ff5252";
        resetCallback();
    } else {
        homeLog.innerText = "❌ 更新失败，未知错误：" + stdoutStr;
        homeLog.style.color = "#ff5252";
        resetCallback();
    }
}
